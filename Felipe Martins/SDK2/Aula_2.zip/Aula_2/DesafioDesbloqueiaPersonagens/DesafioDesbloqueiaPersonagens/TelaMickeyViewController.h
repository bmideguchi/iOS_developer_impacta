//
//  TelaMickeyViewController.h
//  DesafioDesbloqueiaPersonagens
//
//  Created by Felipe Martins on 01/07/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TelaMickeyViewController : UIViewController
- (IBAction)voltarTelaPrincipal:(UIButton *)sender;

@end
