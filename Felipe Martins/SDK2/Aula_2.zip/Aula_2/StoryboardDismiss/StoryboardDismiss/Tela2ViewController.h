//
//  Tela2ViewController.h
//  StoryboardDismiss
//
//  Created by Felipe Martins on 28/06/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Tela2ViewController : UIViewController

- (IBAction)voltarSemSegue:(UIButton *)sender;




@end
