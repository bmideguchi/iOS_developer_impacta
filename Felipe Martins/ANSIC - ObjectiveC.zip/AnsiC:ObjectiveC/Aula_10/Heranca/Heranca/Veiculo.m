

#import "Veiculo.h"

@implementation Veiculo

@synthesize qtdRodas;
@synthesize combustivel;

@end
