

/* Quando trabalhamos comHerança podemos trabalhar com herança entre nossas próprias classes, o que é um recurso muito poderoso para criação de sistemas e reutilizção de código.
 
 */

#import "Veiculo.h"

@interface Moto : Veiculo

@property (nonatomic, retain) NSString *modalidade;
@property (nonatomic, assign) int cilindradas;

@end
