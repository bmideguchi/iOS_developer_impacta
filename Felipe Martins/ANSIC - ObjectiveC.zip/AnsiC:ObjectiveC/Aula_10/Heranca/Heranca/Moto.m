
#import "Moto.h"

@implementation Moto

@synthesize cilindradas;
@synthesize modalidade;

@end
