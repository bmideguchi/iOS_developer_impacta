


#import <Foundation/Foundation.h>

@interface Veiculo : NSObject

@property (nonatomic, retain) NSString *combustivel;
@property (nonatomic, assign) int qtdRodas;

@end
