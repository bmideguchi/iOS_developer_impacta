//
//  Carro.m
//  Heranca
//
//  Created by Felipe Martins on 27/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import "Carro.h"

@implementation Carro

@synthesize aroRodas, qtdRodas;

@end
