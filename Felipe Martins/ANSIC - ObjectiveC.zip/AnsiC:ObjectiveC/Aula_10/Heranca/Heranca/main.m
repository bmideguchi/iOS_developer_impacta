
#import <Foundation/Foundation.h>
#import "Carro.h"
#import "Moto.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        // Criação de um objeto da classe Carro
        Carro *novoCarro = [[Carro alloc]init];
        
        // Atribuindo valores as propriedades que foram herdadas da classe Veiculo.
        
        novoCarro.qtdRodas = 4;
        novoCarro.combustivel = @"Gasosa";
        
        // Atribuindo valores as propriedades da classe Carro
        
        novoCarro.qtdPortas = 4;
        novoCarro.aroRodas = 20;
        
        // Resgatando os valores de sas propriedades
        
        NSLog(@"O carro é movido a %@", novoCarro.combustivel);
        NSLog(@"O carro tem %i portas, %i rodas de aro %i\n\n",novoCarro.qtdPortas,novoCarro.qtdRodas, novoCarro.aroRodas);
        
        //---------------------------------------------------------------------------------
        
        // Criando um onjeto da classe Moto
        
        Moto * novaMoto = [[Moto alloc]init];
        
        // Atribuindo valores para as propriedades que foram herdadas da classse Veiculo
        
        novaMoto.qtdRodas = 2;
        novaMoto.combustivel = @"Gasosa";
        
        // Atribuindo valores as propriedades da classe Moto
        
        novaMoto.cilindradas = 1800;
        novaMoto.modalidade = @"Fuga";
        
        // Exibindo seus valores
        
        NSLog(@"A moto é movida a %@", novaMoto.combustivel);
        NSLog(@"A moto tem %i rodas, %i cilindradas e é da modalidade %@",novaMoto.qtdRodas,novaMoto.cilindradas, novaMoto.modalidade);
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    return 0;
}

