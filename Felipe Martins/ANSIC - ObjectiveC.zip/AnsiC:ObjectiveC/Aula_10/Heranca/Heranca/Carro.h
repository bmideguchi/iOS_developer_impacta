//
//  Carro.h
//  Heranca
//
//  Created by Felipe Martins on 27/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import "Veiculo.h"

@interface Carro : Veiculo

@property (nonatomic, assign) int qtdPortas;
@property (nonatomic, assign) int aroRodas;

@end
