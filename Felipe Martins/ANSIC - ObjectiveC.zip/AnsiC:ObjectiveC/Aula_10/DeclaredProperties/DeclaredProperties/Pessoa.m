

#import "Pessoa.h"

@implementation Pessoa

/* @synthesize
 
 O comando synthesize faz com que o compilador gere os Acessor Methods (Getters e Setters) em tempo de compilação
 
 */

@synthesize nome;
@synthesize idade;

@end
