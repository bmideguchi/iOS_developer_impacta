
#import <Foundation/Foundation.h>

@interface Pessoa : NSObject


/* properties (property).
 
 Propriedades são variáveis declaradas na classe que serão utilizadas pelos objetos que instaciam esta classe.
 
 Declared Properties - São usadas para substituir a declaração e implementação de Accessor Methods e nos fornecem acesso por meio da dotSyntax (.)
 
 sintaxe:
 
 @property (atributosDaPropriedade) Classe *nome;
 @property (atributosDaPropriedade)tipo nome;
 
 
 */


@property (nonatomic,retain) NSString *nome;
@property (nonatomic, assign) int idade;















@end
