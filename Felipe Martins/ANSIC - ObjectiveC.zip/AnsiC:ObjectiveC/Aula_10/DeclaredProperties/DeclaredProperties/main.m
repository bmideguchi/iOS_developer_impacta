
#import <Foundation/Foundation.h>
#import "Pessoa.h"


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        // Criando um objeto de nossa classe Pessoa
        Pessoa *novaPessoa = [[Pessoa alloc]init];
        
        // Atribuindo um valor pelo método SETTER criado automaticamente
        [novaPessoa setNome:@"Garibaldo"];
        [novaPessoa setIdade:98];
        
        //Resgatando os valores pela bracketSyntax
        
        NSLog(@"Nome: %@",[novaPessoa nome]);
        NSLog(@"Idade: %i\n\n", [novaPessoa idade]);
        
        // Atribuindo novos valores por meio da dotSyntax
        novaPessoa.nome = @"Filisbina";
        novaPessoa.idade = 96;
        
        // Resgatando novos valores pela dotSyntax
        
        NSLog(@"Novo Nome: %@", novaPessoa.nome);
        NSLog(@"Nova Idade: %i", novaPessoa.idade);
    
        
        
        
    }
    return 0;
}

