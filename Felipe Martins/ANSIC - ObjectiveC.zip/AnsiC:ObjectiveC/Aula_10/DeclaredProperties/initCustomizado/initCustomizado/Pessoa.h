
#import <Foundation/Foundation.h>

@interface Pessoa : NSObject

@property (nonatomic, retain) NSString *nome;
@property (nonatomic, retain) NSString *sobrenome;


/*init customizado
 
 Podemos criar um método init customizado de acordo com as necessidades do sistema, passando parâmetros e trocando valores das propriedades de nossa Classe.
 
 Seguindo as regras de criação de métodos com parâmetros
 
 */

-(id)initWithNome:(NSString *)umNome andSobrenome:(NSString *)umSobrenome;

@end
