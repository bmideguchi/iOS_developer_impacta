

#import <Foundation/Foundation.h>
#import "NSString+StringReversa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *nomeInverso = [NSString stringReversa:@"Garibaldo Junior"];
        
        NSLog(@"%@", nomeInverso);
        
    }
    return 0;
}

