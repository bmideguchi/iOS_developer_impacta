//
//  Funcionario.m
//  DesafioHeranca
//
//  Created by Felipe Martins on 29/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import "Funcionario.h"

@implementation Funcionario

@synthesize numeroPis;


// Implementação dos métodos

+(void)baterPonto:(NSString *)umNome{

    NSLog(@"%@ está batendo o ponto!",umNome);

}

// Implementando o método initCustomizado


-(id)initWithNome:(NSString *)umNome andSobrenome:(NSString *)umSobrenome andIdade:(int)umaIdade andNumeroPis:(NSUInteger)umNumeroPis{



    self = [super init];
    
    if (self) {
        
        // DICA: sempre utilizar o prefixo self para chamar uma propriedade
        
        self.numeroPis = umNumeroPis;
        self.nome = umNome;
        self.sobrenome = umSobrenome;
        self.idade = umaIdade;
        
    }

    return self;

}














@end
