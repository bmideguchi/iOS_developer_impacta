

#import <Foundation/Foundation.h>

// Importando a classe Funcionario
#import "Funcionario.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
       // Criando e preenchendo suas propriedades com init customizado que criamos
        
        Funcionario *novoFuncionario = [[Funcionario alloc]initWithNome:@"Garibaldo" andSobrenome:@"Souza" andIdade:98 andNumeroPis:5362532635223];
        
        // Chamando o método respirar (heradado da classe pessoa)
        
        [Funcionario respirar:novoFuncionario.nome];
        
        // Exibindo todas as propriedades do objeto de nossa classe Funcionario
        
        NSLog(@"Nome: %@", novoFuncionario.nome);
        NSLog(@"Sobrenome: %@", novoFuncionario.sobrenome);
        NSLog(@"Idade: %i", novoFuncionario.idade);
        NSLog(@"Numero do Pis: %lu", novoFuncionario.numeroPis);
        
        // Chamandop o método ater ponto
        
        [Funcionario baterPonto:novoFuncionario.nome];
        
        
        
    }
    return 0;
}

