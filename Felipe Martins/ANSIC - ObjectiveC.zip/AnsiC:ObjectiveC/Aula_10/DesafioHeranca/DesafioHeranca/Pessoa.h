//
//  Pessoa.h
//  DesafioHeranca
//
//  Created by Felipe Martins on 29/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Pessoa : NSObject

// Criação das propriedades

@property (nonatomic, retain) NSString * nome;
@property (nonatomic, retain) NSString *sobrenome;
@property (nonatomic, assign) int idade;

// Criação do método respirar

+(void)respirar:(NSString *)umNome;

@end
