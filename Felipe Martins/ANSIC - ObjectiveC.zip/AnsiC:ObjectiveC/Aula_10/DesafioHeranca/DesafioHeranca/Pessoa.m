//
//  Pessoa.m
//  DesafioHeranca
//
//  Created by Felipe Martins on 29/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import "Pessoa.h"

@implementation Pessoa

// synthesize das propriedades declaradas no Pessoa.h
@synthesize nome, sobrenome;
@synthesize idade;


// Implementação do método

+(void)respirar:(NSString *)umNome{

    NSLog(@"%@ está respirando",umNome);

}

@end
