

#import "Pessoa.h"

// Funcionario herda a classe Pessoa por se tratar de uma classe totalmente personilzada
@interface Funcionario : Pessoa

// Criação da propriedade NumeroDoPis

@property (nonatomic, assign) NSUInteger numeroPis;



// Criação dos métodos da minha classe Funcionario


// Declaração do método bater ponto
+(void)baterPonto:(NSString *)umNome;

// Criando um init customizado com todas as propriedades da  classe
-(id)initWithNome:(NSString *)umNome andSobrenome:(NSString *)umSobrenome andIdade:(int)umaIdade andNumeroPis:(NSUInteger)umNumeroPis;

@end
