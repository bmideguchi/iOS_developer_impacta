//
//  main.c
//  DesafioListaCompras
//
//  Created by Felipe Martins on 10/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    // Quando temos variáveis do mesmo tipo podemos fazer a declaração em uma única linha separando-as por vírgula.
    
    int qtdLeite, qtdOvos, qtdCarne, qtdFarinha, qtdFeijao;
    
    qtdLeite = 3;
    qtdOvos = 12;
    
    // Atribuição múltipla
    qtdCarne = qtdFarinha = 1;
    
    
    qtdFeijao = 2;
    
    float precoLeite, precoOvos, precoCarne, precoFarinha, precoFeijao;
    
    precoLeite = 1.50;
    precoOvos = 0.25;
    precoCarne = 30.00;
    precoFarinha = 2.00;
    precoFeijao = 3.00;
    
    float total = (precoLeite *qtdLeite) + (precoOvos * qtdOvos) + (qtdCarne * precoCarne) +(precoFarinha * qtdFarinha) + (precoFeijao * qtdFeijao);
    
   
    puts("-----------CONSOLE------------\n\n");
    
    printf("%i Leite = %.2f\n",qtdLeite, qtdLeite * precoLeite);
    printf("%i Ovos = %.2f\n",qtdOvos, qtdOvos * precoOvos);
    printf("%i Carne = %.2f\n",qtdCarne, qtdCarne * precoCarne);
    printf("%i Farinha = %.2f\n",qtdFarinha, qtdFarinha * precoFarinha);
    printf("%i Feijão = %.2f\n",qtdFeijao, qtdFeijao * precoFeijao);
    
    printf("\nTotal: %.2f", total);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}

