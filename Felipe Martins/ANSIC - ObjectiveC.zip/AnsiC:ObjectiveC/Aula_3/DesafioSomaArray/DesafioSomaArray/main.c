//
//  main.c
//  DesafioSomaArray
//
//  Created by Felipe Martins on 10/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{
    
    // Aqui estamos declarando os 2 Arrays
    int array1 [8] = {1,2,3,4,5,4,7,9};
    int array2 [6] = {10,9,8,7,6,2};
    
    // Aqui criamos variáveis para receber a soma de suas respectivas posições.
    int soma1 = array1[0] + array2[0];
    int soma2 = array1[1] + array2[1];
    int soma3 = array1[2] + array2[2];
    int soma4 = array1[3] + array2[3];
    int soma5 = array1[4] + array2[4];
    
    // Aqui exibimos a soma de suas posições
    printf(" O valor da soma da Primeira posição dos Arrays é: %i\n", soma1);
    printf(" O valor da soma da Segunda posição dos Arrays é: %i\n", soma2);
    printf(" O valor da soma da Terceira posição dos Arrays é: %i\n", soma3);
    printf(" O valor da soma da Quarta posição dos Arrays é: %i\n", soma4);
    printf(" O valor da soma da Quinta posição dos Arrays é: %i\n", soma5);
    
    // Esta variável recebe o tamanho do Array
    int tamanho1 = sizeof(array1)/sizeof(array1[0]);
    int tamanho2 = sizeof(array2)/sizeof(array2[0]);
    

    // Exibindo o ultimo elemento
    printf("\n O último elemento do array1 é: %i \n", array1[tamanho1 -1]);
    printf("\n O último elemento do array2 é: %i \n", array2[tamanho2 -1]);
    
    // Printando o tamanho do meu Array
    
    printf("\nO tamanho do meu primeiro array é: %i\n", tamanho1);
    printf("O tamanho do meu segundo array é: %i\n", tamanho2);
    
    
    
    return 0;
}

