//
//  main.c
//  Arrays e Ponteiros
//
//  Created by Felipe Martins on 10/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#include <stdio.h>

// Constante - É um determinado dado que não pode sofrer alteração no decorrer da execução de um programa.

#define PI 3.14

int main(int argc, const char * argv[])
{

    /* Arrays
     
     Arrays são estruturas de dados capazes de armazenar diversos valores do mesmo tipo.
     
     Como uma "Caixinha de Bis".
     
     - As posições de um Array sempre são iniciadas em 0.
     - O ultimo elemento de um Array é sempre a quantidade de registros - 1;
     - Não é possível fazer atribuição simples entre Arrays
     
     
     */
    
    
    // Formas de declaração
    
    int array1[5] = {20,23,12,15,10};
    
    int array2[5];
    
    // Preencher as posições após a declaração
    
    array2[0] = 5;
    array2[1] = 3;
    array2[2] = 1;
    array2[3] = 0;
    array2[4] = 9;
    
    // Resgate de determinado elemento pelo índice de um Array
    
    printf("O valor do elemento na primeira posição é: %i\n", array2[0]);
    printf("O valor do elemento na Segunda posição é: %i\n", array2[1]);
    printf("O valor do elemento na Terceira posição é: %i\n", array2[2]);
    printf("O valor do elemento na Quarta posição é: %i\n", array2[3]);
    printf("O valor do elemento na Quinta posição é: %i\n\n", array2[4]);
    
    // Atribuição de elementos entre 2 Arrays
    
    int array3[1];
    
    array3[0] = array2[2];
    
    printf("Valor do Array3: %i\n\n", array3[0]);
    
    // Função sizeof();
    // A finção sizaof() me retorna o tamanho da minha variável
    
    int variavel1 = 10;
    float variavel2 = 3.14;
    char letra = 'A';
    
    
    
    printf("O peso de uma variável inteira é: %lu\n", sizeof(variavel1));
    printf("O peso de uma variável float é: %lu\n", sizeof(variavel2));
    printf("O peso de uma variável char é: %lu\n", sizeof(letra));
    printf("O peso do Array3 é: %lu\n", sizeof(array3));
    
    
    // Descobrindo o tamanho de um Array pelo sizeof()
    
    
    printf("\n\nO tamanho do meu Array3 é: %lu\n\n", sizeof(array3)/sizeof(array3[0]));
    
    
    // Printando uma constante
    
    
    printf(" O valor de PI é: %.2f\n\n", PI);

    
    /*
     
     Ponteiros.
     
     Ponteiro é uma variável capaz de guardar o endereçamento de memória de outra variável
     
     */
    
    
    
    int item1 = 10;
    int *ponteiro = &item1;
    

    
    printf("\n\n Ponteiro: %p\n\n", ponteiro);
    printf("  Valor: %i", *ponteiro);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}

