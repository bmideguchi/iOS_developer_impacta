//
//  main.c
//  Estrutura Condicinal If
//
//  Created by Felipe Martins on 10/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    /* Estrutura condicional IF
     
     O IF é uma estrutura condicional que permite a tomada de decisões baseada em uma expressão lógica
     
     sintaxe:
     
     if(Expressão Lógica){
     
     
     // Caso a expressão seja verdadeira este bloco de código será executado
     
     }else{
     
     
     // Caso a expressão lógica seja falsa este bloco de código será executado
     
     
     
     }
     
    
     - Operadores lógicos
     
     Maior que >
     Menor que <
     Maior ou igual que >=
     Menor ou igual que <=
     Igual a ==
     Diferente de !=
     
     
     
     AND - &&
     OU - ||
     
     */
    
    
    
    
    
    int idade = 18;
    
    //paiDeixa = 1 (pode beber)
    //paiDeixa = 0 (não pode beber)
    
    int paiDeixa = 1;
    
    
    // Quando utilizamos um if seguido de um else, as duas condições NUNCA serão satisfeitas.
    
    if (idade >= 18) {
        
        puts("Maior de idade e pode dirigir");
        
    }else{
    
    
        puts("Di menó mano, e não podi dirigi!!!\n\n");
    
    }
    
    
    
    puts("------------------------------------");
    
    // ifs independentes são como checkbox - Todos as expressões podem ser satisfeitas ou nenhuma delas
    
    if (idade >= 18) {
        
        
        puts("Pode beber\n");
    }
    
    if (paiDeixa == 1) {
        
        puts("(paiDeixa)Pode beber");
    }
    
    //
    
    
    
    puts("------------------------------------");
    
    // Quando usamos um if seguido de um else if podemos acrescentar uma nova expressão lógica ao nosso fluxo.

    
    if (idade >= 18) {
        
        puts("Pode pular de paraquedas");
        
    }else if (paiDeixa == 1){
    
    
        puts("O pai deixa pular de paraquedas");
    
    
    }
    
    
    
     puts("------------------------------------");
    
    // Quando utilizamos um OU (||) apenas uma das condições precisa ser satisfeita
    
    if (idade >= 18 || paiDeixa ==1) {
        
        
        puts("Eu pulo de qualquer jeito");
    }
    
    
    puts("------------------------------------");
    
    // Quando utilizamos o && todas as condições devem ser satisfeitas
    
    if (idade >= 18 && paiDeixa == 1) {
        
        
        puts("Vou pulaaaaaaarrrrrrr!!!!");
    }
    
    
    
    
    
    
    
    return 0;
}

