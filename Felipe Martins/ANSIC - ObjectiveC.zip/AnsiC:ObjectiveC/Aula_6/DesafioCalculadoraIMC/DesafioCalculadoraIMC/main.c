
#include <stdio.h>

// Declaração ca função (assinatura);
void calculaIMC(float novoPeso, float novaAltura);

int main(int argc, const char * argv[])
{

    float peso;
    float altura;
    
    puts("Insira seu peso: ");
    scanf("%f",&peso);
    
    puts("Insira sua altura: ");
    scanf("%f",&altura);
    
    calculaIMC(peso, altura);
    
    
    
    
    return 0;
}

void calculaIMC(float novoPeso, float novaAltura){

    float imc = novoPeso / (novaAltura * novaAltura);
    
    
    if (imc < 18.5) {
        
        
        puts("Excesso de magreza");
    }
    
    if (imc > 18.5 && imc <= 25) {
        
        
        puts("Peso normal");
    }
    
    if (imc > 25 && imc <= 30) {
        
        puts("Excesso de peso");
    
    }
    
    if (imc > 30 && imc <= 35) {
        
        
        puts("Obesidade Grau 1");
        
    }
    
    if (imc > 35 && imc <= 40) {
        
        puts("Obesidade Grau 2");
    }
    
    if (imc > 40) {
        
        puts("Obesidade grau 3");
    }
    
    
    
    



}