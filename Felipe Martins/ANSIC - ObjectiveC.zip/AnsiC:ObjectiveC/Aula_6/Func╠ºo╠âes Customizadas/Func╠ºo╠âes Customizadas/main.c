#include <stdio.h>

// Além de usarmos funções próprias do sistema, podemos criar nossas próprias finções para processamentos específicos ao nosso programa.

// Declaração de uma função:


/*
 
 tipoDeRetorno nomeDaFuncao(parametros){
 
 
 
 }
 
 */


// Função sem retorno e sem parâmetros


void exibeNome(){
    
    puts("Meu nome é Martins");
    
}

// Função sem retorno e com parametros

void exibeSoma (int num1, int num2){

    printf("A soma é: %i \n", num2+num1);


}

// Função com parametros e com retorno

int multiplicaNumeros(int num1, int num2){


    int total = num1 * num2;

    return total;
}

int main(int argc, const char * argv[])
{

    
    
    
    
    exibeNome();
  
    exibeSoma(5,10);
    
   int resultado = multiplicaNumeros(5, 2);
    
    printf("O resultado da multiplicação é: %i\n", resultado);
    
    
    
    
    return 0;
}

