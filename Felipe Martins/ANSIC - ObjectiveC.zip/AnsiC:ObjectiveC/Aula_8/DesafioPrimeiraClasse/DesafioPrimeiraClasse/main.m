
#import <Foundation/Foundation.h>

// criando a declaração de nossa classe
@interface  Cliente: NSObject {
// Criação das propriedades

    NSString *nome;
    NSString *sobrenome;
    int idade;

}

// Métodos Getters

-(NSString *)getNome;
-(NSString *)getSobrenome;
-(int)getIdade;

// Métodos Setters

-(void)setNome:(NSString *)novoNome;
-(void)setSobrenome:(NSString *)novoSobrenome;
-(void)setIdade:(int)novaIdade;

@end

// Aqui iniciamos a impementação da nossa classe
@implementation Cliente

// Metodos Getters

-(NSString *)getNome{

    return nome;

}

-(NSString *)getSobrenome{


    return sobrenome;

}

-(int)getIdade{


    return idade;

}

// Metodos Setters

-(void)setNome:(NSString *)novoNome{


    nome = novoNome;

}

-(void)setSobrenome:(NSString *)novoSobrenome{

    sobrenome = novoSobrenome;


}


-(void)setIdade:(int)novaIdade{

    idade = novaIdade;


}



@end






int main(int argc, const char * argv[])
{

    Cliente *novoCliente = [[Cliente alloc]init];
    
    
    [novoCliente setNome:@"Garibaldo"];
    [novoCliente setSobrenome:@"Oliveira"];
    [novoCliente setIdade:97];
    
    NSLog(@"Nome: %@",[novoCliente getNome]);
    NSLog(@"Sobrenome: %@", [novoCliente getSobrenome]);
    NSLog(@"Idade: %i", [novoCliente getIdade]);
    
    

    
    
    
    
    
    return 0;
}

