
#import <Foundation/Foundation.h>

/*
 
 Para criarmos uma classe devemos utilizar @interface e marcamos o final da definição de nossa classe com @end
 
 */

// Início da implementacão da classe Pessoa
@interface Pessoa : NSObject{

    
    // Criação das propriedades
    NSString *nome;
    int sala;

}
// Entre a última chave e o @end (Que é o espaço para meus métodos) colocamos os respectivos métodos

// Para acessar as prorpiedade de uma classe somos obrigados a criar os métodos de acesso. Chamados de GETTERS e SETTERS

// MÉTODOS GETTERS - Para resgatar os valores das propriedades

-(NSString*)getNome;
-(int)getSala;


// MÉTODOS SETTERS - Para alteração dos valores

-(void)setNome:(NSString *)novoNome;
-(void)setSala:(int)novaSala;

// Aqui acaba minha parte de @interface
@end

@implementation Pessoa


// Implementação do métodos GETTERS


-(NSString *)getNome{

    return nome;

}

-(int)getSala{

    return sala;

}

// Implementacão dos métodos SETTERS

-(void)setNome:(NSString *)novoNome{

    nome = novoNome;


}

-(void)setSala:(int)novaSala{

    sala = novaSala;


}






@end



int main(int argc, const char * argv[])
{

   /*Abaixo estamos criando um objeto de nome novaPessoa, esse objeto herda todas as propriedade e métodos definidos na classe Pessoa.
    
    Após criarmos o objeto utilizamos [alloc] para allocar o mesmo na memória.
    
    O método [init] fará com que o mesmo seja iniciado.
    
    */
    
    
    // Aqui estamos allocando memória
    Pessoa *novaPessoa = [[Pessoa alloc]init];
    
    // Após um objeto allocado e inicializado podemos interagir com o mesmo.
    
   // Atribuindo valores às propriedades da nossa novaPessoa por meio dos métodos SETTERS
    
 
    [novaPessoa setNome:@"Garibaldo"];
    [novaPessoa setSala:23];
    
    
    
    // Resgatando os valores por meio de nossos métodos GETTERS
    
    NSLog(@"Nome: %@", [novaPessoa getNome]);
    NSLog(@"Sala: %i", [novaPessoa getSala]);
  
  //-------------------------------------------
    // Criando um novo objeto da minha classe Pessoa.
    
    Pessoa *novaPessoa2 = [[Pessoa alloc]init];
    
    [novaPessoa2 setNome:@"Filisbina"];
    [novaPessoa2 setSala:23];
    
    NSLog(@"Nome2: %@",[novaPessoa2 getNome]);
    NSLog(@"Sala2: %i", [novaPessoa2 getSala]);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   
    
    
    
    
    return 0;
}

