// Em ObjC ao invés de utilizar bibliotecas utilizamos os frameworks que são uma espécie de junção de várias bibliotecas. Neste caso para utilizar o framework usamos o #import.

//Quando trabalhamos com Objective-C podemos implementar orientação a objeto (POO). Para isso podemos dividir os trechos de código em arquivos.h (interface) e arquivos.m (Implementação).

// O Framework padrão em ObjC é o Foundation.

// Sempre que vamos manipular objetos devemos utilizar o caractere @.




#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    
    
    
    // Para utilizarmos mensagen de log ao invés de printf utilizamos o comando NSLog.
    
    NSLog(@"Olá mundo");
    
    // Em ObjC temos um dado String nativo!!!!!!
    
    //Aqui estamos criando um Objeto (variável) do tipo NSString (texto) e allocando em memória a partir do método [NSString alloc].
    //Obs: Todo objeto NECESSÁRIAMENTE deve ser declarado como ponteiro (*).
    
    NSString *nome = [NSString alloc];
    
    // Depois de um objeto allocado em memória, devemos iniciá-lo para que possamos interagir com ele.
    nome = [nome init];
    
    // Aqui estamos atribuindo um valor para minha variável nome
    nome = @"Garibaldo";
    
    // Aqui estamos criando uma variável do tipo inteiro. Variáveis primitivas NÃO são tratadas como objeto, logo não as declaramos como ponteiro (*)
    int idade = 98;
    
    
    NSLog(@"Olá mundo meu nome é %@ e minha idade é %i",nome,idade);
    
    
    

       return 0;
}

