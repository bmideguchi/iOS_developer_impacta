
/*
 
 Comentário
 
 De
 
 Bloco
 
 */


// Comentário de linha - O Xcode entende um comentário de linha por "//".

// Acentuação


/*
 
 Acentuação padrão de Ambiente Mac OS
 
 Acento agudo - option + e
 tio - option + n
 chapeuzinho - option + i
 Cedilha - option + c
 Crase - option + crase
 
 */


// Um programa em C basicamente é dividido em 2 partes.

// Header - Esta acima da nossa função principal (main) e pode ser usado para inclusão de bibliotecas. Por exemplo - #include <stdio.h>

// Inicio do Header

#include <stdio.h>

// Final do Header

// - Função main() - É a função principal do meu programa.

// Inicio da nossa função main()
int main(int argc, const char * argv[])
{
    // Aqui dentro da nossa função main podemos fazer a implementação de nosso programa.
    
    
    // Caracteres de escape.
    
    /*
     
     \n - Insere uma quebra de linha no local em que se encontra.
     \t - Insere uma tabulação horizontal
     \" - Insere uma "
     
     
     */
    
    
    // printf - função que gera uma saída de texto em meu console.
    
    printf("Olá mundo meu nome é Felipe\n\n");
    
    printf("Estou no treinamento de iOS\n\n");
    
    printf("Printando um \\n");
    
    printf("\n\n \"Batatinha quando nasce, esparrama pelo chão\" \n\n");
    
    printf("Tabulação horizontal - item1\t\t\titem2\n\n");
    
    
   
    
    return 0; // Aqui temos o retorno de nossa função main().
    
    
    
    
} // Término da nossa função principal main().










