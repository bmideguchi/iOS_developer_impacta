//
//  main.c
//  DesafioOlaMundo
//
//  Created by Felipe Martins on 06/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    // puts - puts é uma função que printa um texto já com quebra de linha. Quebra de linha automática
    
    puts("Meu nome é Felipe e estou no treinamento de iOS e não falei do puts e sacaneei todo mundo\n");
    
    puts("Brincando com tabulação item1 \t item2");
    
    puts("\"Agora um poema\"");
    
    
    return 0;
}

