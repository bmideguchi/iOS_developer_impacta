
#import <Foundation/Foundation.h>

@interface Calculadora : NSObject


// Aqui estamos declarando os métodos para a classe

+(float)somarNumero:(float)num1 comNumero:(float)num2;

+(float)subtrairNumero:(float)num1 comNumero:(float)num2;

+(float)multiplicarNumero:(float)num1 comNumero:(float)num2;

+(float)dividirNumero:(float)num1 comNumero:(float)num2;

@end
