
#include <stdio.h>

// Inclusão da biblioteca std lib.h para que possamos utilizar as funções randômicas
#include <stdlib.h>


void sorteiaCarros();


int main(int argc, const char * argv[])
{

  // Criando a opção de controle
    
    int opc = 1;
    
    
    // Criando o laço que controla a quantidade de execuções
    
    do {
        
        // Chamando a função mque faz o sorteio
        
        sorteiaCarros();
        
        
        // Pedindo a intervenção do usuário para que o prograa continue executando ou não
        puts("Digite 1 para continuar ou 2 para sair: ");
        scanf("%i",&opc);
        
        
      // Verificação da opção que determina a permanência no laço
    } while (opc == 1);
    
    
    
    if (opc == 2) {
        
        puts("Programa encerrado");
    }else{
    
        puts("Você digitou uma opção inválida e o programa será finalzado automáticamente");
    
    }
    
    
    
    return 0;
}






void sorteiaCarros(){

    // Criação do array de string que armazenará os carros
    char arrayCarros [10][256] = {"Ferrari", "Porsche", "Fiat 147", "Lamborghini","Gurgel","Fusca","Jetta","C5", "Uno", "BMW"};
    
    // Criação da variável que armazena o número randômico sorteado
    int sorteado = arc4random()%10;
    
    //Exibindo o carro sorteado
    
    printf("O carro sorteado foi: %s\n\n", arrayCarros[sorteado]);
    
    
    

}