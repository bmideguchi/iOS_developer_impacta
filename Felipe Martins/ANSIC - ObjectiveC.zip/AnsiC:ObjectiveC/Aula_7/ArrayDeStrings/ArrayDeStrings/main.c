#include <stdio.h>

int main(int argc, const char * argv[])
{

   
    /* Podemos criar um array de array de caracteres , ou seja, um array de string
     
     
     Para que possamos criar arrays de tipo strin devemos seguir as informações abaixo:
     
     char nome_array[qtd_elementos][qtd_caracteres] = {"string1","string2"};
     
     */
    
    char nomes[3][256] = {"Garibaldo","Filisbina","Florentina"};
    
printf("Resgatando o primeiro elemento do Array: %s", nomes[0]);

    // Resgatando um item dentro de um item de nosso array de arrays. 
    
printf("Resgatando o primeiro elemento do Array: %c", (nomes[2])[3]);
    
    
   
    return 0;
}

