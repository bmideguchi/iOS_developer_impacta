
#include <stdio.h>
#include <math.h>
#define CONSTANTE 3.23

int main(int argc, const char * argv[])
{
    
   

   // A partir da biblioteca math.h podemos utlizar diversas funções matemática.
    
    
    /* Função pow() - Faz a elevação de um numero a determinada potência.
     
     
     Quando desejamos utilizar a função pow() de maneira direta, devemos resgatar os dados como float.
     
     
     Para resgatarmos como int devemos utilizar a função pow() e alocar em uma variável do tipo int.
     
     */
    
    int elevacao = pow(2, 3);
    printf("O valor da elevação é: %i\n",elevacao);
    
    // podemos fazer uma conversão de tipo utilizando (tipoDeDado)variavelQueSeráConvertida.
    //printf("O Resgate pela função pow de maneira direta: %i\n", (int)pow(2,3));
    printf("O Resgate pela função pow de maneira direta: %.2f\n", pow(2,3));
    
    
    // Além de funções podemos utilizar "constantes" da biblioteca, como por exemplo o PI
    
    float valorPI = M_PI;
    printf("\nO valor do PI é: %f\n",valorPI);
    printf("O valor da CONSTANTE é: %f\n\n", CONSTANTE);
    
    // função round() - Função de arredondamento para o inteiro mais próximo
    
    float soma = 10 + 5.4;
    
    printf("A soma é: %.2f \n", soma);
    printf("Utilizando a função round o resultado da soma é: %.2f\n",round(soma));
    
    
    // função ceil() - Função de arredondamento para cima
    
    float soma2 = 10 + 2.2;
    
    printf("\nA soma2 é: %.2f\n",soma2);
    printf("Utilizando a função ceil o resultado da soma2 é: %.2f", ceil(soma2));
    
    
    // função floor() - Função de arredondamento para baixo
    
    float soma3 = 5 +2.9;
    
    printf("\n\nA soma3 é: %.2f\n", soma3);
    printf("Utilizando a função floor o resultado da soma3 é: %.2f", floor(soma3));
    
    // Precedência de operadores
    
    /*
     
     Quando desamos que determinada operação matemática seja resolvida de maneira preferencial podemos utilizar a precedência de operadores utilizando parenteses
     
     
     
     */
    
    
    int valor1 = 10;
    int valor2 = 1;
    
    printf("\n\nPrecedencia: %i\n", valor1 + valor2 * 4);
    printf("Precedencia forçada com paenteses: %i\n", (valor1 + valor2) * 4);
    
    
    
    return 0;
}

