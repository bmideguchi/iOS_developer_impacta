

#include <stdio.h>

int main(int argc, const char * argv[])
{

    // Operadores Matemáticos
    
   /*
    
    Adição - Tem a função de somar (+)
    Subtração - Tem a função de subtrair (-)
    Multiplicação - Tem a função de multiplicar (*)
    Divisão - Tem a função de dividir (/)
    
    */
    
    
    int saldo = 1000;
    
    // Exemplo de subtracão
    int novoSaldo = saldo - 10;
    printf("O novo saldo subtraído é: %i\n\n", novoSaldo);
    
    // Exemplo de adição
    novoSaldo = saldo +10;
    printf("Agora o meu novo saldo adicionado é %i\n\n", novoSaldo);
    
    // Exemplo de multiplicação
    novoSaldo = saldo *2;
    printf("Agora o meu saldo multiplicado é %i\n\n", novoSaldo);
    
    // Para divisão vamos criaremos duas variáveis
    
    
    int numero1 = 21;
    int numero2 = 10;
    // Importante - É muito interessante saber que não é possível dividir por 0. Nunca! Jamais! Em hipotese nenhuma e nem que a vaca va pro brejo.
    
    // Aqui estamos fazendo a divisão
    float total = numero1 / numero2;
    
    printf("O total da divisão é: %.2f\n\n", total);
    
    // O operador % (MOD) nos retorna o resto da divisão
    int restoDaDivisao = numero1 % numero2;
    
    printf("Resto da divisao %i", restoDaDivisao);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    return 0;
}

