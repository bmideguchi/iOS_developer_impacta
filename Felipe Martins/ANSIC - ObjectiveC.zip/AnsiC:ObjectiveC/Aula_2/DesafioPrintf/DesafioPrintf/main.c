//
//  main.c
//  DesafioPrintf
//
//  Created by Felipe Martins on 08/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    
    printf("-----------CONSOLE-------------\n\nprintnf é uma função que tem por finalidade exibir determinado texto de maneira formatada\n\nNos permite utilizar caracteres de escape como por exemplo (\\n)\n\nSeguindo esta mesma linha temos a função puts()que exibe um texto com quebra de linha automática");
    return 0;
}

