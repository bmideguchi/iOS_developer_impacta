
//  Created by Felipe Martins on 08/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    /*
     
    Variáveis - Variáveis são repositórios de dados (Caixinhas), onde posso armazenar determinados valores.
     
     
     Qualificadores.
     
     Tipo - Tipo de dado que minha "caixinha" irá armazenar.
     Nome - É o nome da minha "caixinha".
     Valor - É o valor que colocamos dentro da caixinha
     
     Escopo - Onde minha variável pode ser acessada e alterada
     
     
     Tipos Primitivos
     
     int - Guarda números inteiros - 30, 21, 445, 10000.
     float - Armazena números "quebrados" (de ponto flutuante) - 3.14, 22.50, 1.45
     char - Armazena caracteres - 'F', 's', '3'.
     ponteiro - Armazena o endereço de memória de outra variável
     long - Interão - Armazena números inteiros longos - 4566544845548.
     
     */
    
    // tipo nome = valor; Criação de uma variável com atribuição.

    
    int idade = 153;

    //
    
    // Criação de uma variável sem atribução
    
    // tipo nome;
    float peso;
    
    peso = 73.50;
    
    // Criando duas variáveis para soma;
    
    int variave1 = 10;
    int variavel2 = 20;
    float variavelFloat = 50.20;
    
    float total = variave1 + variavelFloat;
    
    //
    
    char letra = 'F';
    
    // Vetor ou Array
    
    // Vetor ou Array é uma variável capaz de armazenar diversos valores do mesmo tipo.
    
    // É importantíssimo declarar o sentilena '\0' que determina o final do meu Array.
    
    char nome[7] = {'F','E','L','I','P','E','\0'};
    
    char sobrenome[] = "Martins";
    
    printf("\n\nO nome é: %s\n\n", nome);
    
    
printf("A letra do meu nome é %c, meu peso é %.2f, minha idade %i.\n\n",letra,peso,idade+10);
    
    idade = idade - 10;
    
printf("A letra do meu nome é %c, meu sobrenome é %s, meu peso é %.2f e minha idade é %i.\n\n\n",letra,sobrenome,peso,idade);


    
    printf("A soma das minhas variáveis é: %.2f", total);
    
    return 0;
}

