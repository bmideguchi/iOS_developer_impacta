//
//  main.c
//  DesafioPrevisao
//
//  Created by Felipe Martins on 08/05/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    int idade = 21;
    float conta = 10.00;
    
    
    // Não é possível exibir variáveis utilizando a função puts()
   // puts("Hoje eu tenho %i anos e minha conta tem saldo de R$ %.2f", idade,conta);
    
    printf("Hoje eu tenho %i anos e minha conta tem saldo de R$ %.2f\n\n", idade, conta);
    printf("No próximo ano terei %i anos e minha conta terá saldo de %.2f\n\n", idade+1, conta + 100000);
    
    printf("O valor atual da minha idade é: %i \n\ne o valor atual da minha conta é %.2f", idade, conta);
    
    
    return 0;
}

