//
//  ViewController.h
//  UILocalNotification
//
//  Created by Felipe Martins on 16/08/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)notificar:(UIButton *)sender;

@end
