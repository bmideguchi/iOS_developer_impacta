//
//  Tela2ViewController.h
//  NotificationTabbedApplication
//
//  Created by Felipe Martins on 21/08/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Tela2ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *textFieldUnica;
- (IBAction)dispararNotificacao:(UIButton *)sender;



@end
