//
//  ListaGravacoesViewController.h
//  DesafioGravacao
//
//  Created by Felipe Martins on 28/08/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ListaGravacoesViewController : UITableViewController

@property (nonatomic, strong) NSArray *listaGravacoes;

@end
