//
//  ViewController.h
//  CABasicAnimation
//
//  Created by Felipe Martins on 19/08/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *viewzinha;
- (IBAction)animar:(UIButton *)sender;

@end
