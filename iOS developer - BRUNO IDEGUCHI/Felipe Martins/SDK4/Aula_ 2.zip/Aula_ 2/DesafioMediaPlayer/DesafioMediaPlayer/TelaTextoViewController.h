//
//  TelaTextoViewController.h
//  DesafioMediaPlayer
//
//  Created by Felipe Martins on 14/08/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TelaTextoViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextView *textViewUnica;

@end
