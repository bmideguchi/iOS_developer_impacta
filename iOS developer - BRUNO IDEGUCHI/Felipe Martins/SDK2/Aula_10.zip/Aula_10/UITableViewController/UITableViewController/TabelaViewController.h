//
//  TabelaViewController.h
//  UITableViewController
//
//  Created by Felipe Martins on 17/07/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabelaViewController : UITableViewController


// Criando dois arrays para alimentar nossa tableView

@property (nonatomic, strong) NSArray *arrayCDs;
@property (nonatomic, strong) NSArray *arrayFilmes;

@end
