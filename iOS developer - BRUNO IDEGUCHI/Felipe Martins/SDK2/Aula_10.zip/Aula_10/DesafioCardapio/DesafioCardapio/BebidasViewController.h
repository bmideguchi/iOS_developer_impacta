//
//  BebidasViewController.h
//  DesafioCardapio
//
//  Created by Felipe Martins on 19/07/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BebidasViewController : UITableViewController

@property (nonatomic, strong) NSArray *arrayBebidas;

@end
