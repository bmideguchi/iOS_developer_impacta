

#import <UIKit/UIKit.h>

// Adicionando o delegate ao projeto
@interface ViewController : UIViewController <UIActionSheetDelegate>
- (IBAction)ativarActionSheet:(UIButton *)sender;

@end
