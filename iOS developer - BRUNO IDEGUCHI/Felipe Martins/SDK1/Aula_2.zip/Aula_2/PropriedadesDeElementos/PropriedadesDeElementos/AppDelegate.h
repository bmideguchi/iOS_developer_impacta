


#import <UIKit/UIKit.h>
#import "ViewController.h"

// criando uma referência para nossa classe ViewController
@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, retain) ViewController *controlador;


@end
