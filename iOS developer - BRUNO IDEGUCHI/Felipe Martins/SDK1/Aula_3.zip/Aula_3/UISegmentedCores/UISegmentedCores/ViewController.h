//
//  ViewController.h
//  UISegmentedCores
//
//  Created by Felipe Martins on 05/06/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@property (retain, nonatomic) IBOutlet UISegmentedControl *segmentedMudarCores;

- (IBAction)alterarSegmentedCores:(UISegmentedControl *)sender;

//



@end
