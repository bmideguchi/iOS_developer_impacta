//
//  ViewController.h
//  GeometriaDeView
//
//  Created by Felipe Martins on 15/07/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


// Método que será disparado pelo botao que criamos via código
-(void)metodoParaOButao;

@end
