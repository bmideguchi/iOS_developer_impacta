//
//  SobremesasViewController.h
//  DesafioCardapio
//
//  Created by Felipe Martins on 19/07/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SobremesasViewController : UITableViewController


@property (nonatomic, strong) NSArray *arraySobremesas;

@end
