

#import <UIKit/UIKit.h>

@interface PratosViewController : UITableViewController

@property (nonatomic, strong) NSArray *arrayPratos;

@end
