//
//  ViewController.h
//  GravacaoDicionario
//
//  Created by Felipe Martins on 08/07/13.
//  Copyright (c) 2013 Felipe Martins. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) NSDictionary *dicionarioDados;

@end
